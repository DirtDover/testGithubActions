# NIST.800.30-Risk-Assessment-Tool
# LANL C number #C19091 
# Author: Karl Pommer
# Certifications: CISSP, CISA, CRISC, PMP
#
