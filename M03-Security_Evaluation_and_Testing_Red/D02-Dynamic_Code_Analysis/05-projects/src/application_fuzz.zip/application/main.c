#include <stdio.h>
#include <stdlib.h>
#include "src/api.h"

int main() {
    printf("Starting API server...\n");

    start_api_server();

    return 0;
}
