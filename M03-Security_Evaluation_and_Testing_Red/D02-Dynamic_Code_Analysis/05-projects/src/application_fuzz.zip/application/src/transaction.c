#include <mysql/mysql.h>
#include <stdio.h>
#include <stdbool.h>
#include "transaction.h"
#include "db.h"

bool process_transaction(MYSQL *conn, const char *sender_account, const char *receiver_account, float amount) {
    char query[256];

    snprintf(query, sizeof(query), "SELECT balance FROM accounts WHERE account_number='%s'", sender_account);
    if (mysql_query(conn, query)) {
        fprintf(stderr, "Query failed: %s\n", mysql_error(conn));
        return false;
    }

    MYSQL_RES *result = mysql_store_result(conn);
    if (result == NULL) {
        fprintf(stderr, "mysql_store_result() failed: %s\n", mysql_error(conn));
        return false;
    }

    MYSQL_ROW row = mysql_fetch_row(result);
    if (row == NULL) {
        fprintf(stderr, "No result found for account %s\n", sender_account);
        mysql_free_result(result);
        return false;
    }

    float sender_balance = atof(row[0]);
    mysql_free_result(result);

    if (sender_balance < amount) {
        printf("Insufficient funds for account %s\n", sender_account);
        return false;
    }

    snprintf(query, sizeof(query), "UPDATE accounts SET balance = balance - %.2f WHERE account_number='%s'", amount, sender_account);
    if (mysql_query(conn, query)) {
        fprintf(stderr, "Failed to update sender account: %s\n", mysql_error(conn));
        return false;
    }

    snprintf(query, sizeof(query), "UPDATE accounts SET balance = balance + %.2f WHERE account_number='%s'", amount, receiver_account);
    if (mysql_query(conn, query)) {
        fprintf(stderr, "Failed to update receiver account: %s\n", mysql_error(conn));
        return false;
    }

    snprintf(query, sizeof(query), "INSERT INTO transactions (account_number, amount, sender_account, receiver_account) VALUES ('%s', %.2f, '%s', '%s')", sender_account, amount, sender_account, receiver_account);
    if (mysql_query(conn, query)) {
        fprintf(stderr, "Failed to insert transaction: %s\n", mysql_error(conn));
        return false;
    }

    printf("Transaction successful from %s to %s for amount %.2f\n", sender_account, receiver_account, amount);
    return true;
}

bool process_transactions(json_value *json) {
    MYSQL *conn = connect_db();
    if (conn == NULL) {
        fprintf(stderr, "Error connecting to the database\n");
        return false;
    }

    for (int i = 0; i < json->u.object.length; i++) {
        json_value *transaction = json->u.object.values[i].value;

        const char *sender = transaction->u.object.values[0].value->u.string.ptr;
        const char *receiver = transaction->u.object.values[1].value->u.string.ptr;
        double amount = transaction->u.object.values[2].value->u.dbl;

        if (!process_transaction(conn, sender, receiver, (float)amount)) {
            close_db(conn);
            return false;
        }
    }


    close_db(conn);
    return true;
}