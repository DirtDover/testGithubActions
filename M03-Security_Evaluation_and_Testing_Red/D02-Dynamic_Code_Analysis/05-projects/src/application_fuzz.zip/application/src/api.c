#include <stdio.h>
#include "mongoose.h"
#include "json.h"
#include "transaction.h"

static void handle_transactions(struct mg_connection *conn, int ev, void *ev_data) {
    if (ev == MG_EV_HTTP_MSG) {
        struct mg_http_message *hm = (struct mg_http_message *) ev_data;

        char *json_body = (char *) malloc(hm->body.len + 1);
        if (!json_body) {
            mg_http_reply(conn, 500, "", "{\"error\":\"Memory allocation failed\"}\n");
            return;
        }

        // Copy the body content and add a null terminator
        memcpy(json_body, hm->body.buf, hm->body.len);
        json_body[hm->body.len] = '\0';  // Add null terminator

        printf("Received JSON: %s\n", json_body);
        // Now parse the JSON with the null-terminated string
        json_value *parsed_json = json_parse(json_body, strlen(json_body));

        free(json_body);  // Free the temporary buffer

        if (parsed_json == NULL) {
            mg_http_reply(conn, 500, "", "{\"error\":\"Error parsing JSON\"}\n");
            return;
        }

        bool transaction_status = process_transactions(parsed_json);

        if (transaction_status) {
            mg_http_reply(conn, 200, "", "{\"status\":\"Transaction processed successfully\"}\n");
        } else {
            mg_http_reply(conn, 500, "", "{\"status\":\"Transaction failed due to an internal error\"}\n");
        }

        json_value_free(parsed_json);


    }
}

static void handle_status(struct mg_connection *conn, int ev, void *ev_data) {
    if (ev == MG_EV_HTTP_MSG) {
        mg_http_reply(conn, 200, "", "{\"status\":\"Server is running\"}\n");
    }
}

static void fn(struct mg_connection *c, int ev, void *ev_data) {
    if (ev == MG_EV_HTTP_MSG) {  // New HTTP request received
        struct mg_http_message *hm = (struct mg_http_message *) ev_data;  // Parsed HTTP request
        if (mg_match(hm->uri, mg_str("/api/transactions"), NULL)) {
            handle_transactions(c, ev, ev_data);
        } else if (mg_match(hm->uri, mg_str("/api/status"), NULL)) {
            handle_status(c, ev, ev_data);
        } else {
            struct mg_http_serve_opts opts = {.root_dir = "."};  // For all other URLs,
            mg_http_serve_dir(c, hm, &opts);                     // Serve static files
        }
    }
}

int start_api_server() {
    struct mg_mgr mgr;
    mg_mgr_init(&mgr);
    mg_http_listen(&mgr, "http://0.0.0.0:8000", fn, NULL);

    for (;;) {
    mg_mgr_poll(&mgr, 1000);
    }
    mg_mgr_free(&mgr);
    return 0;
}