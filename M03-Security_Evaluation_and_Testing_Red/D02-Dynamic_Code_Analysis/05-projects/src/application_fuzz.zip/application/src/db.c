#include <mysql/mysql.h>
#include <stdio.h>
#include <stdlib.h>
#include "db.h"

MYSQL* connect_db() {
    MYSQL *conn = mysql_init(NULL);

    if (conn == NULL) {
        fprintf(stderr, "mysql_init() failed\n");
        return NULL;
    }

    const char *server = getenv("DB_SERVER");
    const char *user = getenv("DB_USER");
    const char *password = getenv("DB_PASSWORD");
    const char *database = getenv("DB_NAME");

    if (mysql_real_connect(conn, server, user, password, database, 0, NULL, 0) == NULL) {
        fprintf(stderr, "mysql_real_connect() failed\n");
        mysql_close(conn);
        return NULL;
    }

    return conn;
}

void close_db(MYSQL *conn) {
    mysql_close(conn);
}