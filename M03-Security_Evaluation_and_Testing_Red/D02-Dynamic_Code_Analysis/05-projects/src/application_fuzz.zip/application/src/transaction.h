#ifndef TRANSACTION_H
#define TRANSACTION_H

#include "json.h"

bool process_transactions(json_value *json);

#endif