#ifndef UTILS_H
#define UTILS_H

void print_table_header(int num_columns, ...);
void print_table_row(int num_columns, ...);

#endif
