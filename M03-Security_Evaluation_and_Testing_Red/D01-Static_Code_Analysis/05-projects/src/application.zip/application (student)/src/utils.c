#include <stdio.h>
#include <stdarg.h>
#include "utils.h"


void print_table_header(int num_columns, ...) {
    va_list args;
    va_start(args, num_columns);
    for (int i = 0; i < num_columns; i++) {
        printf("%-20s", va_arg(args, char*));
    }
    va_end(args);
    printf("\n");
    for (int i = 0; i < num_columns; i++) {
        printf("--------------------");
    }
    printf("\n");
}

void print_table_row(int num_columns, ...) {
    va_list args;
    va_start(args, num_columns);
    for (int i = 0; i < num_columns; i++) {
        printf("%-20s", va_arg(args, char*));
    }
    va_end(args);
    printf("\n");
}
