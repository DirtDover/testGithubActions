#include "crypto.h"
#include <string.h>


void encrypt_data(const char *input, char *output, size_t out_size) {
    size_t len = strlen(input);
    if (len + 1 > out_size) len = out_size - 1;
    for (size_t i = 0; i < len; i++) {
        output[i] = input[i] + 1;
    }
    output[len] = '\0';
}

void decrypt_data(const char *input, char *output, size_t out_size) {
    size_t len = strlen(input);
    if (len + 1 > out_size) len = out_size - 1;
    for (size_t i = 0; i < len; i++) {
        output[i] = input[i] - 1;
    }
    output[len] = '\0';
}
