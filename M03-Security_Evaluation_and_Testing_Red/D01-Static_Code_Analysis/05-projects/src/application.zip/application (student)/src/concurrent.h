#ifndef CONCURRENT_H
#define CONCURRENT_H

#include <mysql/mysql.h>

void concurrent_update_balance(MYSQL *conn, const char *account_number, float amount);

#endif
