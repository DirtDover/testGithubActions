#ifndef LOGGER_H
#define LOGGER_H


void send_log_to_aggregator(const char *level, const char *message, const char *username);

#endif
