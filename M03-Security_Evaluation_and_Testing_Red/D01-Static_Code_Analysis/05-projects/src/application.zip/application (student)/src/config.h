#ifndef CONFIG_H
#define CONFIG_H

#include <stdlib.h>

static inline int is_secure_mode() {
    const char *val = getenv("SECURE_MODE");
    return (val && val[0] == '1');
}

#endif
