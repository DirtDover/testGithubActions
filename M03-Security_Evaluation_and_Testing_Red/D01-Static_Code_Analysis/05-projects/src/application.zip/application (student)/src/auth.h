#ifndef AUTH_H
#define AUTH_H

#include <mysql/mysql.h>

MYSQL* authenticated_connect_db();

#endif
