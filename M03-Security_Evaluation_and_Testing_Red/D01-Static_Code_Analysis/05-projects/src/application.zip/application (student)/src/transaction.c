#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <mysql/mysql.h>
#include "transaction.h"
#include "utils.h"
#include "policy.h"
#include "crypto.h"


int is_valid_account_number(const char *acc) {
    if (strlen(acc) != 10) return 0;
    for (int i = 0; i < 10; i++) {
        if (!isdigit((unsigned char)acc[i])) return 0;
    }
    return 1;
}

void display_account(MYSQL *conn, const char *account_number) {
    char display_buffer[20];
    strncpy(display_buffer, account_number, sizeof(display_buffer)-1);
    display_buffer[sizeof(display_buffer)-1] = '\0';

    if (!is_valid_account_number(display_buffer)) {
        printf("Invalid account number format.\n");
        return;
    }

    MYSQL_STMT *stmt = mysql_stmt_init(conn);
    const char *q = "SELECT account_number, balance, pii_encrypted FROM accounts WHERE account_number=?";
    mysql_stmt_prepare(stmt, q, strlen(q));

    MYSQL_BIND bind[1];
    memset(bind, 0, sizeof(bind));
    bind[0].buffer_type = MYSQL_TYPE_STRING;
    bind[0].buffer = display_buffer;
    bind[0].buffer_length = strlen(display_buffer);
    mysql_stmt_bind_param(stmt, bind);

    mysql_stmt_execute(stmt);

    MYSQL_BIND result_bind[3];
    memset(result_bind, 0, sizeof(result_bind));
    char accbuf[21];
    char balbuf[21];
    char piibuf[128];

    result_bind[0].buffer_type = MYSQL_TYPE_STRING;
    result_bind[0].buffer = accbuf;
    result_bind[0].buffer_length = 20;

    result_bind[1].buffer_type = MYSQL_TYPE_STRING;
    result_bind[1].buffer = balbuf;
    result_bind[1].buffer_length = 20;

    result_bind[2].buffer_type = MYSQL_TYPE_STRING;
    result_bind[2].buffer = piibuf;
    result_bind[2].buffer_length = 127;

    mysql_stmt_bind_result(stmt, result_bind);

    if (mysql_stmt_fetch(stmt) == 0) {
        print_table_header(3, "Account Number", "Balance", "Customer Info");
        char dec[128];
        decrypt_data(piibuf, dec, sizeof(dec));
        print_table_row(3, accbuf, balbuf, dec);
    } else {
        printf("Account not found.\n");
    }

    mysql_stmt_close(stmt);
}

void process_transaction(MYSQL *conn, const char *sender_account, const char *receiver_account, float amount) {
    char query[256];

    sprintf(query, "SELECT balance FROM accounts WHERE account_number='%s'", sender_account);
    mysql_query(conn, query);
    MYSQL_RES *result = mysql_store_result(conn);
    if (!result) {
        return;
    }

    MYSQL_ROW row = mysql_fetch_row(result);
    if (!row) {
        mysql_free_result(result);
        return;
    }

    float sender_balance = atof(row[0]);
    mysql_free_result(result);

    if (sender_balance < amount) {
        printf("Insufficient funds in account %s\n", sender_account);
        return;
    }

    sprintf(query, "UPDATE accounts SET balance = balance - %.2f WHERE account_number='%s'", amount, sender_account);
    mysql_query(conn, query);
    sprintf(query, "UPDATE accounts SET balance = balance + %.2f WHERE account_number='%s'", amount, receiver_account);
    mysql_query(conn, query);

    printf("Transaction of %.2f from account %s to account %s completed successfully.\n", amount, sender_account, receiver_account);
}

void view_transaction_history(MYSQL *conn, const char *account_number) {
    printf("Displaying transaction history for account: %s\n", account_number);
    char query[256];
    sprintf(query, "SELECT transaction_id, amount, date FROM transactions WHERE account_number='%s'", account_number);
    mysql_query(conn, query);
    MYSQL_RES *result = mysql_store_result(conn);
    if (!result) {
        return;
    }

    MYSQL_ROW row;
    print_table_header(3, "Transaction ID", "Amount", "Date");
    while ((row = mysql_fetch_row(result))) {
        print_table_row(3, row[0], row[1], row[2]);
    }

    mysql_free_result(result);
}

void rollback_transaction(MYSQL *conn, int transaction_id) {
    char *sender_account = malloc(20 * sizeof(char));
    char *receiver_account = malloc(20 * sizeof(char));
    float amount;
    char query[256];

    sprintf(query, "SELECT sender_account, receiver_account, amount FROM transactions WHERE transaction_id=%d", transaction_id);
    mysql_query(conn, query);
    MYSQL_RES *result = mysql_store_result(conn);
    if (!result) {
        free(sender_account);
        free(receiver_account);
        return;
    }

    MYSQL_ROW row = mysql_fetch_row(result);
    if (!row) {
        printf("Transaction not found.\n");
        mysql_free_result(result);
        free(sender_account);
        free(receiver_account);
        return;
    }

    strcpy(sender_account, row[0]);
    strcpy(receiver_account, row[1]);
    amount = atof(row[2]);
    mysql_free_result(result);

    sprintf(query, "UPDATE accounts SET balance = balance + %.2f WHERE account_number='%s'", amount, sender_account);
    mysql_query(conn, query);
    sprintf(query, "UPDATE accounts SET balance = balance - %.2f WHERE account_number='%s'", amount, receiver_account);
    mysql_query(conn, query);

    free(sender_account);
    free(receiver_account);

    printf("Transaction with ID %d has been rolled back successfully.\n", transaction_id);
}
