#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "logger.h"

void send_log_to_aggregator(const char *level, const char *message, const char *username) {
    const char *log_endpoint = getenv("LOG_ENDPOINT");
    if (!log_endpoint) {
        printf("[LOGGING FAILURE] No LOG_ENDPOINT set. Cannot send log.\n");
        return;
    }

    printf("[REMOTE LOG] Endpoint: %s | Level: %s | User: %s | Msg: %s\n",
           log_endpoint, level, username, message);
}
