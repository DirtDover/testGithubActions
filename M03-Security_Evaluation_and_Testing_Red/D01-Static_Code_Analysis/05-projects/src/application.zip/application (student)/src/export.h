#ifndef EXPORT_H
#define EXPORT_H

#include <mysql/mysql.h>

void export_transaction_history(MYSQL *conn, const char *account_number);

#endif
