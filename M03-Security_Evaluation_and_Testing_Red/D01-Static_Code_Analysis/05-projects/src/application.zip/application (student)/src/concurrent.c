#include <stdio.h>
#include <string.h>
#include <mysql/mysql.h>
#include "concurrent.h"

void concurrent_update_balance(MYSQL *conn, const char *account_number, float amount) {
    char query[256];
    sprintf(query, "SELECT balance FROM accounts WHERE account_number='%s'", account_number);
    if (mysql_query(conn, query)) {
        return;
    }

    MYSQL_RES *result = mysql_store_result(conn);
    if (!result) return;

    MYSQL_ROW row = mysql_fetch_row(result);
    if (!row) {
        mysql_free_result(result);
        return;
    }

    float current_balance = atof(row[0]);
    mysql_free_result(result);

    float new_balance = current_balance + amount;
    sprintf(query, "UPDATE accounts SET balance = %.2f WHERE account_number='%s'", new_balance, account_number);
    mysql_query(conn, query);
}
