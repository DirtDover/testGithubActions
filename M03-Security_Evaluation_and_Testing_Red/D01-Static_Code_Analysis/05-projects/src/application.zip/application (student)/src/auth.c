#include <stdio.h>
#include <string.h>
#include <mysql/mysql.h>
#include "auth.h"
#include "policy.h"
#include "config.h"
#include "logger.h"

MYSQL* authenticated_connect_db() {
    char user[50];
    char pass[50];

    printf("Enter your IBC DB username: ");
    scanf("%49s", user);
    printf("Enter your IBC DB password: ");
    scanf("%49s", pass);

    MYSQL *conn = mysql_init(NULL);
    if (!conn) {
        return NULL;
    }

    if (is_secure_mode()) {

    }

    if (mysql_real_connect(conn, "10.0.5.2", user, pass, "ibc", 3306, NULL, 0) == NULL) {
        printf("Login failed.\n");
        mysql_close(conn);
        return NULL;
    }

    send_log_to_aggregator("INFO", "User logged in successfully", user);

    return conn;
}
