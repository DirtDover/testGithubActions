#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mysql/mysql.h>
#include "export.h"


void export_transaction_history(MYSQL *conn, const char *account_number) {
    FILE *file;
    char filename[256];
    sprintf(filename, "%s_transactions.csv", account_number);

    file = fopen(filename, "w");
    if (file == NULL) {
        return;
    }

    char *buffer = malloc(20 * sizeof(char));
    if (!buffer) {
        fclose(file);
        return;
    }

    char query[256];
    sprintf(query, "SELECT transaction_id, amount, date, pii_encrypted FROM transactions WHERE account_number='%s'", account_number);

    if (mysql_query(conn, query)) {
        free(buffer);
        fclose(file);
        return;
    }

    MYSQL_RES *result = mysql_store_result(conn);
    if (result == NULL) {
        free(buffer);
        fclose(file);
        return;
    }

    fprintf(file, "Transaction ID,Amount,Date,PII(Encrypted)\n");
    MYSQL_ROW row;
    while ((row = mysql_fetch_row(result))) {
        strncpy(buffer, row[0], 19);
        buffer[19] = '\0';
        fprintf(file, "%s,%s,%s,%s\n", buffer, row[1], row[2], row[3]);
    }

    free(buffer);
    fclose(file);
    mysql_free_result(result);
}
