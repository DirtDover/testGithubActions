#ifndef UTILS_H
#define UTILS_H

#include <stdio.h>
#include <string.h>
#include <ctype.h>

// Utility functions to print tables safely and validate inputs.

void print_table_header(int num_columns, ...);
void print_table_row(int num_columns, ...);

int is_valid_account_number(const char *acc);
const char* double_to_str(double value);
const char* int_to_str(int value);

#endif
