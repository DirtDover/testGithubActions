#include <stdio.h>
#include <string.h>
#include <mysql/mysql.h>
#include <stdlib.h>
#include "auth.h"
#include "policy.h"
#include "config.h"
#include "logger.h"

// Secure authentication:
// - Credentials are read from environment variables (e.g. DB_USER, DB_PASSWORD, DB_HOST).
// - No username or password is logged.
// - Ensures least privilege: we assume DB credentials have minimal access rights.

MYSQL* authenticated_connect_db() {
    const char *db_user = getenv("DB_USER");
    const char *db_pass = getenv("DB_PASSWORD");
    const char *db_host = getenv("DB_HOST");
    const char *db_name = getenv("DB_NAME");

    if (!db_user || !db_pass || !db_host || !db_name) {
        fprintf(stderr, "Missing DB_USER, DB_PASSWORD, DB_HOST, or DB_NAME environment variables.\n");
        return NULL;
    }

    MYSQL *conn = mysql_init(NULL);
    if (!conn) {
        return NULL;
    }

    // Enable SSL/TLS if desired (assuming the MySQL server supports it)
    // mysql_options(conn, MYSQL_OPT_SSL_MODE, (const char *)MYSQL_SSL_MODE_REQUIRED);

    if (!mysql_real_connect(conn, db_host, db_user, db_pass, db_name, 3306, NULL, 0)) {
        fprintf(stderr, "Database connection failed: %s\n", mysql_error(conn));
        mysql_close(conn);
        return NULL;
    }

    // Log only the fact that a connection was made, without sensitive details.
    send_log_to_aggregator("INFO", "Database connection established successfully.");

    return conn;
}
