#include <stdarg.h>
#include <stdlib.h>
#include "utils.h"

// Safe utility functions

void print_table_header(int num_columns, ...) {
    va_list args;
    va_start(args, num_columns);
    for (int i = 0; i < num_columns; i++) {
        printf("%-20s", va_arg(args, char*));
    }
    va_end(args);
    printf("\n");
    for (int i = 0; i < num_columns; i++) {
        printf("--------------------");
    }
    printf("\n");
}

void print_table_row(int num_columns, ...) {
    va_list args;
    va_start(args, num_columns);
    for (int i = 0; i < num_columns; i++) {
        printf("%-20s", va_arg(args, char*));
    }
    va_end(args);
    printf("\n");
}

int is_valid_account_number(const char *acc) {
    if (!acc) return 0;
    size_t len = strlen(acc);
    if (len != 10) return 0;
    for (size_t i = 0; i < len; i++) {
        if (!isdigit((unsigned char)acc[i])) return 0;
    }
    return 1;
}

// Convert double and int to string safely
const char* double_to_str(double value) {
    static char buffer[64];
    snprintf(buffer, sizeof(buffer), "%.2f", value);
    return buffer;
}

const char* int_to_str(int value) {
    static char buffer[32];
    snprintf(buffer, sizeof(buffer), "%d", value);
    return buffer;
}
