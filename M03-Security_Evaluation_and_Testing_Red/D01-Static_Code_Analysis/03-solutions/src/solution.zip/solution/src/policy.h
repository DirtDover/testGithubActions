#ifndef POLICY_H
#define POLICY_H

// Now we enforce that transactions above MIN_APPROVAL_AMOUNT require manager approval.
#define IBC_SEC_POLICY "IBC_SEC_POLICY_V3"
#define MIN_APPROVAL_AMOUNT 10000.00
#define MAX_FAILED_LOGINS 3

#endif
