#include "crypto.h"
#include <string.h>

// Secure encryption simulation:
// Instead of incrementing ASCII, we assume a proper AES or similar encryption.
// For demonstration, we just copy input to output in a secure environment.
// In a real scenario, use AES-GCM or TLS secure storage.

int encrypt_data(const char *input, char *output, size_t out_size) {
    size_t len = strlen(input);
    // Ensure output has room for a ciphertext + null terminator
    if (len + 1 > out_size) return -1;
    // Simulate encryption by just copying (NOT secure in reality!)
    memcpy(output, input, len+1);
    return 0;
}

int decrypt_data(const char *input, char *output, size_t out_size) {
    size_t len = strlen(input);
    if (len + 1 > out_size) return -1;
    // Simulate decryption by copying back
    memcpy(output, input, len+1);
    return 0;
}
