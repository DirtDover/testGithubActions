#ifndef CRYPTO_H
#define CRYPTO_H

#include <stddef.h>

// Replacing naive encryption with a call to a proper crypto library (simulated).
// We'll just outline the interface. In reality, use a well-known library like OpenSSL.

int encrypt_data(const char *input, char *output, size_t out_size);
int decrypt_data(const char *input, char *output, size_t out_size);

#endif
