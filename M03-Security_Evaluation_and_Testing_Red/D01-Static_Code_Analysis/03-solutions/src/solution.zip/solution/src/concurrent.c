#include <stdio.h>
#include <string.h>
#include <mysql/mysql.h>
#include "concurrent.h"
#include "utils.h"

// Proper concurrency handling:
// - We run the operation inside a transaction and commit or rollback.
// - Use prepared statements to avoid SQL injection and ensure atomicity.

// Returns 0 on success, -1 on failure.
int concurrent_update_balance(MYSQL *conn, const char *account_number, float amount) {
    if (!is_valid_account_number(account_number)) {
        return -1;
    }

    // Start transaction
    if (mysql_query(conn, "START TRANSACTION")) {
        return -1;
    }

    // Use prepared statements to SELECT current balance
    MYSQL_STMT *stmt = mysql_stmt_init(conn);
    const char *select_q = "SELECT balance FROM accounts WHERE account_number=?";
    if (mysql_stmt_prepare(stmt, select_q, strlen(select_q))) {
        mysql_stmt_close(stmt);
        mysql_query(conn, "ROLLBACK");
        return -1;
    }

    MYSQL_BIND bind[1];
    memset(bind, 0, sizeof(bind));
    bind[0].buffer_type = MYSQL_TYPE_STRING;
    bind[0].buffer = (char*)account_number;
    bind[0].buffer_length = strlen(account_number);

    if (mysql_stmt_bind_param(stmt, bind) || mysql_stmt_execute(stmt)) {
        mysql_stmt_close(stmt);
        mysql_query(conn, "ROLLBACK");
        return -1;
    }

    MYSQL_BIND result_bind[1];
    memset(result_bind, 0, sizeof(result_bind));
    double current_balance;
    result_bind[0].buffer_type = MYSQL_TYPE_DOUBLE;
    result_bind[0].buffer = (char*)&current_balance;
    if (mysql_stmt_bind_result(stmt, result_bind) || mysql_stmt_fetch(stmt)) {
        mysql_stmt_close(stmt);
        mysql_query(conn, "ROLLBACK");
        return -1;
    }

    mysql_stmt_close(stmt);

    double new_balance = current_balance + amount;

    // Update balance with a prepared statement
    stmt = mysql_stmt_init(conn);
    const char *update_q = "UPDATE accounts SET balance=? WHERE account_number=?";
    if (mysql_stmt_prepare(stmt, update_q, strlen(update_q))) {
        mysql_stmt_close(stmt);
        mysql_query(conn, "ROLLBACK");
        return -1;
    }

    MYSQL_BIND update_bind[2];
    memset(update_bind, 0, sizeof(update_bind));

    update_bind[0].buffer_type = MYSQL_TYPE_DOUBLE;
    update_bind[0].buffer = (char*)&new_balance;
    update_bind[1].buffer_type = MYSQL_TYPE_STRING;
    update_bind[1].buffer = (char*)account_number;
    update_bind[1].buffer_length = strlen(account_number);

    if (mysql_stmt_bind_param(stmt, update_bind) || mysql_stmt_execute(stmt)) {
        mysql_stmt_close(stmt);
        mysql_query(conn, "ROLLBACK");
        return -1;
    }

    mysql_stmt_close(stmt);

    // Commit transaction
    if (mysql_query(conn, "COMMIT")) {
        mysql_query(conn, "ROLLBACK");
        return -1;
    }

    return 0;
}
