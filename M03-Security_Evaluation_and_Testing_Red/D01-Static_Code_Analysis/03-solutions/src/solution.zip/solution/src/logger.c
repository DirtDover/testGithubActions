#include <stdio.h>
#include <stdlib.h>
#include "logger.h"

// Secure logging simulation:
// - Uses a remote endpoint from LOG_ENDPOINT env var.
// - In a real scenario, would use HTTPS with certificate validation.
// - Never logs PII, passwords, or other sensitive details.

void send_log_to_aggregator(const char *level, const char *message) {
    const char *log_endpoint = getenv("LOG_ENDPOINT");
    if (!log_endpoint) {
        // If no endpoint, print a safe fallback message.
        fprintf(stderr, "[LOG WARNING] No LOG_ENDPOINT set.\n");
        return;
    }

    // Here, we would send logs via a secure channel.
    // Just print a safe message indicating logging happened.
    // In production, use libcurl or another TLS-capable library.
    fprintf(stdout, "[REMOTE LOG] %s: %s\n", level, message);
}
