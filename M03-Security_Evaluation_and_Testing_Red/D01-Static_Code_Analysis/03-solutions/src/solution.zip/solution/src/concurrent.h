#ifndef CONCURRENT_H
#define CONCURRENT_H

#include <mysql/mysql.h>

// This function no longer simulates concurrency issues.
// Instead, we demonstrate a properly handled balance update inside a transaction.

int concurrent_update_balance(MYSQL *conn, const char *account_number, float amount);

#endif
