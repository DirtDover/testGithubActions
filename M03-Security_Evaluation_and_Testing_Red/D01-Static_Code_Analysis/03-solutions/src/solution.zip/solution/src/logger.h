#ifndef LOGGER_H
#define LOGGER_H

// Logs messages to a remote aggregator securely.
// Sensitive data is never logged in plaintext.
// Communication is assumed to be encrypted (e.g., HTTPS).

void send_log_to_aggregator(const char *level, const char *message);

#endif
