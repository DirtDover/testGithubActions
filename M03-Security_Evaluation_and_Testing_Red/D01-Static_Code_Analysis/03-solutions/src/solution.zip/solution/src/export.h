#ifndef EXPORT_H
#define EXPORT_H

#include <mysql/mysql.h>

// Export transaction history using prepared statements and safe string handling.
// No overflow or injection issues.

int export_transaction_history(MYSQL *conn, const char *account_number);

#endif
