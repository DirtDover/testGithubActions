#ifndef AUTH_H
#define AUTH_H

#include <mysql/mysql.h>

// Authenticates and connects to the database using least-privilege credentials from environment variables.
// Ensures secure input for password and no sensitive info is logged.
MYSQL* authenticated_connect_db();

#endif
