#ifndef TRANSACTION_H
#define TRANSACTION_H

#include <mysql/mysql.h>

int display_account(MYSQL *conn, const char *account_number);
int process_transaction(MYSQL *conn, const char *sender_account, const char *receiver_account, float amount);
int view_transaction_history(MYSQL *conn, const char *account_number);
int rollback_transaction(MYSQL *conn, int transaction_id);

#endif
