#ifndef CONFIG_H
#define CONFIG_H

#include <stdlib.h>

// In a secure mode, we could enforce stricter policies.
// If SECURE_MODE is "1", we could add additional checks.
// For now, we ensure no logging of sensitive data happens anyway.

static inline int is_secure_mode() {
    const char *val = getenv("SECURE_MODE");
    return (val && val[0] == '1');
}

#endif
