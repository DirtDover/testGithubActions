#include "crypto.h"
#include <string.h>

// A trivial "encryption" scheme that just increments ASCII values by 1.
// Vulnerability:
// - Doesn't meet any cryptographic standard or compliance requirement.
// - Sensitive PII is easily recovered if logs or DB entries are accessed by an attacker.

void encrypt_data(const char *input, char *output, size_t out_size) {
    size_t len = strlen(input);
    if (len + 1 > out_size) len = out_size - 1;
    for (size_t i = 0; i < len; i++) {
        output[i] = input[i] + 1;
    }
    output[len] = '\0';
}

void decrypt_data(const char *input, char *output, size_t out_size) {
    size_t len = strlen(input);
    if (len + 1 > out_size) len = out_size - 1;
    for (size_t i = 0; i < len; i++) {
        output[i] = input[i] - 1;
    }
    output[len] = '\0';
}
