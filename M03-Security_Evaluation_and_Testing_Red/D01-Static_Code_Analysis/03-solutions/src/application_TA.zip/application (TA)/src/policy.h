#ifndef POLICY_H
#define POLICY_H

// Internal IBC policy reference that should guide implementation.
// Not fully enforced: e.g., no approval step for large transfers.
#define MIN_APPROVAL_AMOUNT 10000.00
#define MAX_FAILED_LOGINS 3

#endif
