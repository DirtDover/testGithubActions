#ifndef CRYPTO_H
#define CRYPTO_H

#include <stddef.h>

// Extremely weak encryption to highlight non-compliance with security standards.
void encrypt_data(const char *input, char *output, size_t out_size);
void decrypt_data(const char *input, char *output, size_t out_size);

#endif
