#ifndef UTILS_H
#define UTILS_H

// Utility for printing table headers and rows.
// Not directly vulnerable, but must be used carefully to avoid formatting bugs.
void print_table_header(int num_columns, ...);
void print_table_row(int num_columns, ...);

#endif
