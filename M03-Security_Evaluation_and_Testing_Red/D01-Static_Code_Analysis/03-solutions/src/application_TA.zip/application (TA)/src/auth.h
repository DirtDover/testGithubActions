#ifndef AUTH_H
#define AUTH_H

#include <mysql/mysql.h>

// Authenticates and connects to the database using user-supplied credentials.
// Credentials should be of least privilege, but here we risk using overly privileged accounts.
MYSQL* authenticated_connect_db();

#endif
