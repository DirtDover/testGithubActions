#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "logger.h"

// This simulates sending logs to a remote aggregator.
// Vulnerabilities:
// - If LOG_ENDPOINT is not secure (HTTP rather than HTTPS), logs can be intercepted.
// - Username passed directly could contain malicious characters or sensitive info.
// - No sanitization or encryption of logs before sending them.

// In a real system, we might use libcurl or another HTTP client to POST logs to a remote endpoint.
// Here, we just simulate by printing what we "would" send.
// Students should note this output represents data being sent off-site unprotected.

void send_log_to_aggregator(const char *level, const char *message, const char *username) {
    const char *log_endpoint = getenv("LOG_ENDPOINT");
    if (!log_endpoint) {
        // If no endpoint is defined, we pretend to fail silently or fallback to stdout.
        // This is also problematic because logs might get lost.
        printf("[LOGGING FAILURE] No LOG_ENDPOINT set. Cannot send log.\n");
        return;
    }

    // Naive simulation: Just print what would be sent.
    // In a real scenario: Use HTTP POST requests with proper headers and possibly encryption.
    printf("[REMOTE LOG] Endpoint: %s | Level: %s | User: %s | Msg: %s\n",
           log_endpoint, level, username, message);
}
