#ifndef CONFIG_H
#define CONFIG_H

#include <stdlib.h>

// Reads environment variables for toggling secure mode or log endpoint in a real scenario.
// Currently, secure mode is not fully utilized.
// LOG_ENDPOINT should be set for logging. If not, logging fails.

static inline int is_secure_mode() {
    const char *val = getenv("SECURE_MODE");
    return (val && val[0] == '1');
}

#endif
