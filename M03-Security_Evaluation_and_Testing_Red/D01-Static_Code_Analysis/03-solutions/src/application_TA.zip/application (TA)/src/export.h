#ifndef EXPORT_H
#define EXPORT_H

#include <mysql/mysql.h>

// Exports transaction history to CSV without proper sanitization or secure handling.
// Susceptible to SQL injection and buffer overflows.
void export_transaction_history(MYSQL *conn, const char *account_number);

#endif
