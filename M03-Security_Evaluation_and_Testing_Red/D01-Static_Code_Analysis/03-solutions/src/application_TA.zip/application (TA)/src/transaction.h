#ifndef TRANSACTION_H
#define TRANSACTION_H

#include <mysql/mysql.h>

// Transaction-related functions vulnerable to SQL injection, missing input validation, business logic flaws.
void display_account(MYSQL *conn, const char *account_number);
void process_transaction(MYSQL *conn, const char *sender_account, const char *receiver_account, float amount);
void view_transaction_history(MYSQL *conn, const char *account_number);
void rollback_transaction(MYSQL *conn, int transaction_id);

#endif
