#include <stdio.h>
#include <string.h>
#include <mysql/mysql.h>
#include "auth.h"
#include "policy.h"
#include "config.h"
#include "logger.h"

// This authentication routine prompts for DB credentials at runtime.
// Vulnerabilities:
// - Potentially high-privilege DB credentials.
// - Password is entered via scanf() and not masked.
// - The username is logged to a remote aggregator without sanitization or anonymization.
// - Logging sensitive info to a remote endpoint can lead to data exposure.

MYSQL* authenticated_connect_db() {
    char user[50];
    char pass[50];

    printf("Enter your IBC DB username: ");
    scanf("%49s", user);
    // In real scenarios, mask the password. Here it's plainly read.
    printf("Enter your IBC DB password: ");
    scanf("%49s", pass);

    MYSQL *conn = mysql_init(NULL);
    if (!conn) {
        return NULL;
    }

    if (is_secure_mode()) {
        // Secure mode might imply better logging or masking, but we do nothing substantial.
        // Students should note the unfulfilled promise of security improvements.
    }

    // Connect to an internal DB server IP (e.g., a private subnet in a data center).
    // If these credentials are overly privileged, it breaks least privilege principles.
    if (mysql_real_connect(conn, "10.0.5.2", user, pass, "ibc", 3306, NULL, 0) == NULL) {
        printf("Login failed.\n");
        mysql_close(conn);
        return NULL;
    }

    // Instead of writing to a local file, we send logs to a remote aggregator.
    // This introduces a risk of exposing sensitive info (usernames) externally.
    // No sanitization is done, allowing potential log injection if 'user' is malicious.
    send_log_to_aggregator("INFO", "User logged in successfully", user);

    return conn;
}
