#ifndef LOGGER_H
#define LOGGER_H

// Logging interface to send logs to a remote aggregator (log bucket).
// Vulnerability:
// - Sending raw user data without sanitization or anonymization.
// - If logs contain sensitive info, it's exposed externally.
// - No TLS or authentication is mentioned, risking MiTM attacks on log data.

void send_log_to_aggregator(const char *level, const char *message, const char *username);

#endif
