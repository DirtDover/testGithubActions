#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "auth.h"
#include "transaction.h"
#include "export.h"
#include "utils.h"
#include "policy.h"
#include "concurrent.h"

// Main application loop:
// Summarizing vulnerabilities again:
// - Database credentials might be high-privilege, not least-privileged.
// - Logging user info to a remote aggregator without sanitization or encryption.
// - SQL injection, buffer overflows, weak "encryption" of PII.
// - No enforcement of business rules for large transactions.
// - Concurrency issues with balance updates.
// - References to IBC_SEC_POLICY but no real compliance checks.

int main() {
    MYSQL *conn = authenticated_connect_db();
    if (!conn) {
        printf("Failed to connect to database.\n");
        return EXIT_FAILURE;
    }

    while (1) {
        int option;
        printf("1. View Account\n");
        printf("2. Transfer Money\n");
        printf("3. View Transaction History\n");
        printf("4. Export Transaction History to CSV\n");
        printf("5. Rollback Transaction\n");
        printf("6. Concurrent Test (simulate concurrency issue)\n");
        printf("7. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &option);

        if (option == 1) {
            char account_number[20];
            printf("Enter account number: ");
            scanf("%19s", account_number);
            display_account(conn, account_number);
        } else if (option == 2) {
            char sender_account[20], receiver_account[20];
            float amount;
            printf("Enter sender account number: ");
            scanf("%19s", sender_account);
            printf("Enter receiver account number: ");
            scanf("%19s", receiver_account);
            printf("Enter amount to transfer: ");
            scanf("%f", &amount);
            process_transaction(conn, sender_account, receiver_account, amount);
        } else if (option == 3) {
            char account_number[20];
            printf("Enter account number: ");
            scanf("%19s", account_number);
            view_transaction_history(conn, account_number);
        } else if (option == 4) {
            char account_number[20];
            printf("Enter account number to export: ");
            scanf("%19s", account_number);
            export_transaction_history(conn, account_number);
        } else if (option == 5) {
            int transaction_id;
            printf("Enter transaction ID to rollback: ");
            scanf("%d", &transaction_id);
            rollback_transaction(conn, transaction_id);
        } else if (option == 6) {
            char account_number[20];
            float amount;
            printf("Enter account number for concurrent update test: ");
            scanf("%19s", account_number);
            printf("Enter amount to add: ");
            scanf("%f", &amount);
            concurrent_update_balance(conn, account_number, amount);
        } else if (option == 7) {
            printf("Exiting...\n");
            break;
        } else {
            printf("Invalid option. Try again.\n");
        }
    }

    mysql_close(conn);
    return EXIT_SUCCESS;
}
